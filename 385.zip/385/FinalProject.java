
package finalProject;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import com.mysql.cj.jdbc.MysqlDataSource;

import java.awt.*;
import java.sql.*;
import java.util.Objects;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;

public class FinalProject {

    public static MysqlDataSource getSQLDataSource() {
        FileInputStream fis = null;
        MysqlDataSource mysqlDS = null;
        Properties props = new Properties();

        try {
            System.out.println("Working Directory = " + System.getProperty("user.dir"));
            fis = new FileInputStream("./src//db.properties");

            props.load(fis);
            mysqlDS = new MysqlDataSource();
            mysqlDS.setURL(props.getProperty("JDBC_URL"));
            mysqlDS.setUser(props.getProperty("JDBC_USERNAME"));
            mysqlDS.setPassword(props.getProperty("JDBC_PASSWORD"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mysqlDS;
    }

    public static void fillTable(JTable table, String tableName, int year, String category, String status) {
        if (year <= 0) {
            year = 1990;
        }
        if (tableName.equals("Google")) {
            tableName = "google";
        }
        if (tableName.equals("Microsoft")) {
            tableName = "microsoft";
        }

        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
        tableModel.setRowCount(0); 
        MysqlDataSource dataSource = getSQLDataSource();
        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement()) {

            String query = "SELECT Name, Func, Year, Category FROM " + tableName + " WHERE Year >= " + year;

            if (!category.equals("All") && !category.isEmpty()) {
                query += " AND Category = '" + category + "'";
            }

            query += " AND Status = '" + status + "'";

            if (category.equals("All")) {
                query = "SELECT Name, Func, Year, Category FROM " + tableName + " WHERE Year > " + year + " AND Status = '" + status + "'";
            }

            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) { 
                Object[] rowData = {
                        resultSet.getString("Name"),
                        resultSet.getString("Category"),
                        resultSet.getString("Year"),
                        resultSet.getString("Func")
                };
                tableModel.addRow(rowData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> WindowManager.createAndShowGUI());
    }
}

class WindowManager {
    private static JComboBox<String> tableSelector;
    private static JComboBox<String> categorySelector;
    private static JTextField yearField; 
    private static JComboBox<String> statusSelector;
    private static JTable table;

    public static void createAndShowGUI() {
        JFrame frame = initializeFrame();
        JPanel panel = createPanel();
        GridBagConstraints constraints = initializeConstraints();

        addSelectorsToPanel(panel, constraints);
        addQueryAndAddEntryButtons(panel, constraints);
        addTableToFrame(frame, panel);

        displayFrame(frame, 800, 500);
    }

    private static JFrame initializeFrame() {
        JFrame frame = new JFrame("Data Selector");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        return frame;
    }

    private static JPanel createPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        return panel;
    }

    private static GridBagConstraints initializeConstraints() {
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(10, 10, 10, 10);
        return constraints;
    }

    private static void addSelectorsToPanel(JPanel panel, GridBagConstraints constraints) {
        addTableSelector(panel, constraints);
        addCategorySelector(panel, constraints);
        addStatusSelector(panel, constraints);
        addYearSelector(panel, constraints); 
    }

    private static void addYearSelector(JPanel panel, GridBagConstraints constraints) {
        JLabel yearLabel = new JLabel("Minimum Year");
        yearField = new JTextField(10);
        constraints.gridx = 0; 
        constraints.gridy = 1;
        panel.add(yearLabel, constraints);
        constraints.gridx = 1; 
        panel.add(yearField, constraints);
        constraints.gridx = 0; 
    }

    private static void addTableSelector(JPanel panel, GridBagConstraints constraints) {
        JLabel tableLabel = new JLabel("Select Table:");
        String[] tables = {"Microsoft", "Google"};
        tableSelector = new JComboBox<>(tables);
        setComboBoxFixedWidth(tableSelector); 
        panel.add(tableLabel, constraints);
        constraints.gridx = 1;
        panel.add(tableSelector, constraints);
        resetGridPosition(constraints);
    }

    private static void addCategorySelector(JPanel panel, GridBagConstraints constraints) {
        JLabel categoryLabel = new JLabel("Category:");
        String[] categories = {"All", "Web Service", "Productivity/Education", "Operating System", "Social", "Workflow Automation", "Development", "Analytics", "Smart Devices", "Virtual Assistant", "Health", "Language Service"};
        categorySelector = new JComboBox<>(categories);
        setComboBoxFixedWidth(categorySelector);
        constraints.gridx = 3;
        panel.add(categoryLabel, constraints);
        constraints.gridx = 4;
        panel.add(categorySelector, constraints);
        resetGridPosition(constraints);
    }

    private static void addStatusSelector(JPanel panel, GridBagConstraints constraints) {
        JLabel statusLabel = new JLabel("Status:");
        String[] status = {"Active", "Discontinued"};
        statusSelector = new JComboBox<>(status);
        setComboBoxFixedWidth(statusSelector); 
        constraints.gridx = 3;
        constraints.gridy = 1;
        panel.add(statusLabel, constraints);
        constraints.gridx = 4;
        panel.add(statusSelector, constraints);
        resetGridPosition(constraints);
    }

    private static void setComboBoxFixedWidth(JComboBox<String> comboBox) {
        Dimension fixedSize = comboBox.getPreferredSize();
        fixedSize.width = 150; 
        comboBox.setPreferredSize(fixedSize);
    }

    private static void resetGridPosition(GridBagConstraints constraints) {
        constraints.gridx = 0;
        constraints.gridy = 0;
    }

    private static JButton createQueryButton() {
        JButton queryButton = new JButton("Execute Query");
        queryButton.addActionListener(e -> {
            String selectedTable = (String) tableSelector.getSelectedItem();
            int year = 1990;

            String yearText = yearField.getText().trim();
            if (!yearText.isEmpty()) {
                try {
                    year = Integer.parseInt(yearText);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid year!");
                    return;
                }
            }

            String selectedCategory = Objects.requireNonNullElse(categorySelector.getSelectedItem(), "").toString();
            if (selectedCategory.equals("All")) {
                selectedCategory = "";
            }

            String selectedStatus = Objects.requireNonNullElse(statusSelector.getSelectedItem(), "").toString();

            FinalProject.fillTable(table, selectedTable, year, selectedCategory, selectedStatus);
        });
        return queryButton;
    }

    private static JButton createAddEntryButton() {
        JButton addEntryButton = new JButton("Add Entry");
        addEntryButton.addActionListener(e -> {
            JFrame addEntryFrame = createAddEntryFrame();
            displayFrame(addEntryFrame, 400, 250);
        });
        return addEntryButton;
    }

    private static JFrame createAddEntryFrame() {
        JFrame addEntryFrame = new JFrame("Add Entry");
        addEntryFrame.setLayout(new GridLayout(7, 2));

        JLabel tableLabel = new JLabel("Select Table:");
        JComboBox<String> tableComboBox = new JComboBox<>(new String[]{"Microsoft", "Google"});
        addEntryFrame.add(tableLabel);
        addEntryFrame.add(tableComboBox);

        JLabel nameLabel = new JLabel("Entry Name:");
        JTextField nameField = new JTextField();
        addEntryFrame.add(nameLabel);
        addEntryFrame.add(nameField);

        JLabel yearLabel = new JLabel("Year:");
        JTextField yearField = new JTextField();
        addEntryFrame.add(yearLabel);
        addEntryFrame.add(yearField);

        JLabel categoryLabel = new JLabel("Category:");
        JComboBox<String> categoryComboBox = new JComboBox<>(new String[]{"Web Service", "Productivity/Education", "Operating System", "Social", "Workflow Automation", "Development", "Analytics", "Smart Devices", "Virtual Assistant", "Health", "Language Service"});
        addEntryFrame.add(categoryLabel);
        addEntryFrame.add(categoryComboBox);

        JLabel statusLabel = new JLabel("Status:");
        JComboBox<String> statusComboBox = new JComboBox<>(new String[]{"Active", "Discontinued"});
        addEntryFrame.add(statusLabel);
        addEntryFrame.add(statusComboBox);

        JLabel functionLabel = new JLabel("Function:");
        JTextField functionField = new JTextField();
        addEntryFrame.add(functionLabel);
        addEntryFrame.add(functionField);

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            String tableName = Objects.requireNonNull(tableComboBox.getSelectedItem()).toString();
            String entryName = nameField.getText();
            int year = Integer.parseInt(yearField.getText());
            String category = Objects.requireNonNull(categoryComboBox.getSelectedItem()).toString();
            String status = Objects.requireNonNull(statusComboBox.getSelectedItem()).toString();
            String function = functionField.getText();

            insertIntoTable(tableName, entryName, year, category, status, function);

            String selectedTable = Objects.requireNonNull(tableSelector.getSelectedItem()).toString();
            String selectedCategory = Objects.requireNonNullElse(categorySelector.getSelectedItem(), "").toString();
            if (selectedCategory.equals("All")) {
                selectedCategory = "";
            }
            String selectedStatus = Objects.requireNonNullElse(statusSelector.getSelectedItem(), "").toString();
            FinalProject.fillTable(table, selectedTable, year, selectedCategory, selectedStatus);

            addEntryFrame.dispose();
        });
        addEntryFrame.add(saveButton);
        addEntryFrame.setLocationRelativeTo(null); 

        return addEntryFrame;
    }

    private static void insertIntoTable(String tableName, String entryName, int year, String category, String status, String function) {
        MysqlDataSource dataSource = FinalProject.getSQLDataSource();
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement("INSERT INTO " + tableName + " (Name, Year, Category, Status, Func) VALUES (?, ?, ?, ?, ?)")) {

            statement.setString(1, entryName);
            statement.setInt(2, year);
            statement.setString(3, category);
            statement.setString(4, status);
            statement.setString(5, function);

            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    private static void addQueryAndAddEntryButtons(JPanel panel, GridBagConstraints constraints) {
        JButton changeStatusButton = createChangeStatusButton();
        addChangeStatusButtonToPanel(panel, constraints, changeStatusButton);

        JButton addEntryButton = createAddEntryButton();
        addEntryButtonToPanel(panel, constraints, addEntryButton);

        JButton removeEntryButton = createRemoveEntryButton();
        addRemoveEntryButtonToPanel(panel, constraints, removeEntryButton);

        JButton queryButton = createQueryButton();
        addQueryButtonToPanel(panel, constraints, queryButton);
    }
    

    private static JButton createChangeStatusButton() {
        JButton changeStatusButton = new JButton("Change Status");
        changeStatusButton.addActionListener(e -> {
            JFrame changeStatusFrame = createChangeStatusFrame();
            displayFrame(changeStatusFrame, 300, 100);
        });
        return changeStatusButton;
    }
    
    private static JFrame createChangeStatusFrame() {
        JFrame changeStatusFrame = new JFrame("Change Status");
        changeStatusFrame.setLayout(new GridLayout(3, 2));
    
        JLabel tableLabel = new JLabel("Select Table:");
        JComboBox<String> tableComboBox = new JComboBox<>(new String[]{"Microsoft", "Google"});
        changeStatusFrame.add(tableLabel);
        changeStatusFrame.add(tableComboBox);
    
        JLabel nameLabel = new JLabel("Entry Name:");
        JTextField nameField = new JTextField();
        changeStatusFrame.add(nameLabel);
        changeStatusFrame.add(nameField);
    
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            String tableName = Objects.requireNonNull(tableComboBox.getSelectedItem()).toString();
            String entryName = nameField.getText();
    
            changeStatusInTable(tableName, entryName);
            String selectedTable = Objects.requireNonNull(tableSelector.getSelectedItem()).toString();
            String selectedCategory = Objects.requireNonNullElse(categorySelector.getSelectedItem(), "").toString();
            if (selectedCategory.equals("All")) {
                selectedCategory = "";
            }
            String selectedStatus = Objects.requireNonNullElse(statusSelector.getSelectedItem(), "").toString();
            FinalProject.fillTable(table, selectedTable, 1990, selectedCategory, selectedStatus);    
            changeStatusFrame.dispose();
        });
        changeStatusFrame.add(saveButton);
        changeStatusFrame.setLocationRelativeTo(null);
        return changeStatusFrame;
    }
    
    private static void changeStatusInTable(String tableName, String entryName) {
        MysqlDataSource dataSource = FinalProject.getSQLDataSource();
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement("UPDATE " + tableName + " SET Status = CASE WHEN Status = 'Active' THEN 'Discontinued' ELSE 'Active' END WHERE Name = ?")) {
    
            statement.setString(1, entryName);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        String selectedTable = Objects.requireNonNull(tableSelector.getSelectedItem()).toString();
        String selectedCategory = Objects.requireNonNullElse(categorySelector.getSelectedItem(), "").toString();
        if (selectedCategory.equals("All")) {
            selectedCategory = "";
        }
        String selectedStatus = Objects.requireNonNullElse(statusSelector.getSelectedItem(), "").toString();
        FinalProject.fillTable(table, selectedTable, 1990, selectedCategory, selectedStatus);
    }


    private static void addChangeStatusButtonToPanel(JPanel panel, GridBagConstraints constraints, JButton changeStatusButton) {
        constraints.gridx = 1;
        constraints.gridy = 2;
        panel.add(changeStatusButton, constraints);
    }
    
    private static void addQueryButtonToPanel(JPanel panel, GridBagConstraints constraints, JButton queryButton) {
        constraints.gridx = 2;
        constraints.gridy = 3; 
        panel.add(queryButton, constraints);
    }


    private static void addEntryButtonToPanel(JPanel panel, GridBagConstraints constraints, JButton addEntryButton) {
        constraints.gridx = 2;
        constraints.gridy = 2; 
        panel.add(addEntryButton, constraints);
    }



    private static void addRemoveEntryButtonToPanel(JPanel panel, GridBagConstraints constraints, JButton removeEntryButton) {
        constraints.gridx = 3; 
        constraints.gridy = 2;
        panel.add(removeEntryButton, constraints);
    }

    private static JFrame createRemoveEntryFrame() {
        JFrame removeEntryFrame = new JFrame("Remove Entry");
        removeEntryFrame.setLayout(new GridLayout(3, 2));

        JLabel tableLabel = new JLabel("Select Table:");
        JComboBox<String> tableComboBox = new JComboBox<>(new String[]{"Microsoft", "Google"});
        removeEntryFrame.add(tableLabel);
        removeEntryFrame.add(tableComboBox);

        JLabel nameLabel = new JLabel("Entry Name:");
        JTextField nameField = new JTextField();
        removeEntryFrame.add(nameLabel);
        removeEntryFrame.add(nameField);

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(e -> {
            String tableName = Objects.requireNonNull(tableComboBox.getSelectedItem()).toString();
            String entryName = nameField.getText();

            deleteFromTable(tableName, entryName);

            String selectedTable = Objects.requireNonNull(tableSelector.getSelectedItem()).toString();
            String selectedCategory = Objects.requireNonNullElse(categorySelector.getSelectedItem(), "").toString();
            if (selectedCategory.equals("All")) {
                selectedCategory = "";
            }
            String selectedStatus = Objects.requireNonNullElse(statusSelector.getSelectedItem(), "").toString();
            FinalProject.fillTable(table, selectedTable, 1990, selectedCategory, selectedStatus);

            removeEntryFrame.dispose(); 
        });
        removeEntryFrame.add(deleteButton);
        removeEntryFrame.setLocationRelativeTo(null); 
        return removeEntryFrame;
    }
    
    private static JButton createRemoveEntryButton() {
        JButton removeEntryButton = new JButton("Remove Entry");
        removeEntryButton.addActionListener(e -> {
            JFrame removeEntryFrame = createRemoveEntryFrame();
            displayFrame(removeEntryFrame, 300, 100);
        });
        return removeEntryButton;
    }

    private static void deleteFromTable(String tableName, String entryName) {
        MysqlDataSource dataSource = FinalProject.getSQLDataSource();
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement("DELETE FROM " + tableName + " WHERE Name = ?")) {

            statement.setString(1, entryName);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static void addTableToFrame(JFrame frame, JPanel panel) {
        DefaultTableModel model = new DefaultTableModel();
        table = new JTable(model);
        model.addColumn("Name");
        model.addColumn("Category");
        model.addColumn("Year");
        model.addColumn("Function");

        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100); 
        columnModel.getColumn(1).setPreferredWidth(150); 
        columnModel.getColumn(2).setPreferredWidth(10); 
        columnModel.getColumn(3).setPreferredWidth(200); 
        table.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
    }

    private static void displayFrame(JFrame frame, int width, int height) {
        frame.setSize(width, height); 
        frame.setVisible(true); 
    }

}